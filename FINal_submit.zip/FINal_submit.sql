use new_db

alter table Data_final_so
alter column runtime int

alter table Data_final_so
alter column seasons int

alter table Data_final_so
alter column imdb_score float

alter table Data_final_so
alter column imdb_votes int

alter table Data_final_so
alter column tmdb_popularity float

alter table Data_final_so
alter column tmdb_score  float

alter table Data_final_so
alter column No_of_persons_worked int

alter table Data_final_so
alter column No_of_Actors int

alter table Data_final_so
alter column No_of_Directors int

alter table Data_final_so
alter column No_of_uncredited_characters int

select * from DATA_FINAL_so

--Q1
select count(title) no_of_titles from DATA_FINAL_so

--Q2
SELECT (COUNT(CASE WHEN type = 'SHOW' THEN 1 END) * 100.0) / COUNT(*) AS Percentage
FROM DATA_FINAL_so

--Q3
select avg(runtime) avg_runtime_min from DATA_FINAL_so
where type='MOVIE'

--Q4
select count(title) NO_of_prdc_US from DATA_FINAL_so 
where production_countries like '%US%'

--Q5

select title,sum(imdb_votes) imdb_vote from DATA_FINAL_so
order by imdb_vote desc



--Q6

select (COUNT(CASE WHEN type = 'SHOW' or type='MOVIE' 
and genres like ('%drama%') or genres like ('%comedy%') THEN 1 END) * 100.0) / COUNT(*) 
from DATA_FINAL_so

--Q7

select count(type) no_of_movie from DATA_FINAL_so
where type='MOVIE' and imdb_score>tmdb_score
group by type

--Q8
select count(type) no_of_show from DATA_FINAL_so
where type='SHOW' and seasons>5 and production_countries like ('%US%') and imdb_score>7

--Q9
select sum(total_run_time) total_duration from (
select title,sum(runtime) total_run_time from DATA_FINAL_so
where release_year >1985 and age_certification = 'R' and genres like ('%comedy%') or genres like ('%action%')
group by title) tb

--Q10

select  count(type) no_of_tv_show from DATA_FINAL_so
where imdb_score >= 8 and type = 'SHOW'

